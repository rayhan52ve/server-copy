<!-- resources/views/frontend/bkash/success.blade.php -->
@extends('User.layout.master')
@section('user')
<div class="container mt-5">
    <div class="alert alert-success">
        <strong>Success!</strong> Your payment was successful.
    </div>
</div>
@endsection
