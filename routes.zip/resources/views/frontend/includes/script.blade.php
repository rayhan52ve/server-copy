<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script src="{{asset('/')}}frontend/assets/js/jquery.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/bootstrap.bundle.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/form-validator.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/contact-form-script.js"></script>
<script src="{{asset('/')}}frontend/assets/js/aos.js"></script>
<script src="{{asset('/')}}frontend/assets/js/owl.carousel.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/odometer.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/fancybox.js"></script>
<script src="{{asset('/')}}frontend/assets/js/jquery.appear.js"></script>
<script src="{{asset('/')}}frontend/assets/js/tweenmax.min.js"></script>
<script src="{{asset('/')}}frontend/assets/js/main.js"></script>

