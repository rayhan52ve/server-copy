<link href="{{ asset('/') }}admin/assets/node_modules/morrisjs/morris.css" rel="stylesheet">
<!--Toaster Popup message CSS -->
<link href="{{ asset('/') }}admin/assets/node_modules/toast-master/css/jquery.toast.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="{{ asset('/') }}admin/dist/css/style.min.css" rel="stylesheet">
<link href="{{ asset('/') }}admin/dist/css/style.css?v=1.0" rel="stylesheet">
<!-- Dashboard 1 Page CSS -->
<link href="{{ asset('/') }}admin/dist/css/pages/dashboard1.css" rel="stylesheet">
<link rel="stylesheet" type="text/css"
    href="{{ asset('/') }}admin/assets/node_modules/summernote/dist/summernote-bs4.css">
{{-- image upload --}}
<link rel="stylesheet" href="{{ asset('/') }}admin/assets/node_modules/dropify/dist/css/dropify.min.css">

<link href="{{ asset('/') }}admin/assets/node_modules/bootstrap-datepicker/bootstrap-datepicker.min.css"
    rel="stylesheet" type="text/css" />
<link href="{{ asset('/') }}admin/assets/node_modules/select2/dist/css/select2.min.css" rel="stylesheet"
    type="text/css" />
<link href="{{ asset('/') }}admin/assets/node_modules/switchery/dist/switchery.min.css" rel="stylesheet" />
<link href="{{ asset('/') }}admin/assets/node_modules/bootstrap-select/bootstrap-select.min.css" rel="stylesheet" />
<link href="{{ asset('/') }}admin/assets/node_modules/bootstrap-tagsinput/dist/bootstrap-tagsinput.css"
    rel="stylesheet" />
<link href="{{ asset('/') }}admin/assets/node_modules/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css"
    rel="stylesheet" />
<link href="{{ asset('/') }}admin/assets/node_modules/multiselect/css/multi-select.css" rel="stylesheet"
    type="text/css" />
{{-- data table --}}
<link rel="stylesheet" type="text/css"
    href="{{ asset('/') }}admin/assets/node_modules/datatables.net-bs4/css/dataTables.bootstrap4.css">
<link rel="stylesheet" type="text/css"
    href="{{ asset('/') }}admin/assets/node_modules/datatables.net-bs4/css/responsive.dataTables.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/brands.min.css"
    integrity="sha512-9YHSK59/rjvhtDcY/b+4rdnl0V4LPDWdkKceBl8ZLF5TB6745ml1AfluEU6dFWqwDw9lPvnauxFgpKvJqp7jiQ=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.0/jquery.min.js"></script>

{{-- font awesome --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
    integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
    crossorigin="anonymous" referrerpolicy="no-referrer" />
{{-- font awesome --}}

{{-- bangla web font --}}

<style>
    @import url('https://fonts.maateen.me/adorsho-lipi/font.css');

    body {
        font-family: 'AdorshoLipi', sans-serif !important;
    }

    h1,
    h2,
    h3,
    h4,
    h5,
    p,
    li,
    a {
        font-family: 'AdorshoLipi', sans-serif !important;
    }
</style>
{{-- bangla web font --}}
